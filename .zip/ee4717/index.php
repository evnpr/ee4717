<?php
    $base_url = "/test/fun/ee4717/"
?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">

    <title>Hungry Jacks</title>
    <style type="text/css" media="screen">
        #header{
        height: 40px;
        width:  100%;
        background-color: #bebebe;
        }

        #logo{
            float:left;
        }

        #menu{
            float:left;
            margin-left: 30px;
        }

        #content{
        width: 100%;
        border: solid 1px;
        }

        #banner{
        height: 300px;
        width: 70%;
        float:left;
        background-color:blue;
        }

        #sidebar-search{
        height: 300px;
        width: 29%;
        float:right;
        background-color:brown;
        }

        .canteen{
        height: 300px;
        width: 70%;
        float:left;
        background-color: red;
        }

        .sidebar{
        height: 300px;
        width: 29%;
        float:right;
        background-color: orange;
        }

        #footer{
        height: 80px;
        width: 100%;
        background-color: #bebebe;
        }

        .break{
            clear:both;
        }
    </style>

    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/style.css" type="text/css" media="screen" charset="utf-8">
    
</head>

<body>
<div id="wrapper" class="name">
    
    <div id="header" class="name">
        <div id="logo" class="name">
            logo            
        </div>
        <div id="menu" class="name">
           menu 
        </div>
    </div>


    <div id="content" class="name">
        <div id="content-top" class="name">
            
         <div id="banner" class="name">
            this is the banner
         </div>
         <div id="sidebar-search" class="name">
            this is the sidebar-search    
         </div>
        </div>

        <div id="content-bottom" class="name">
            
         <div id="" class="canteen">
            canteen 
         </div>
         <div id="" class="sidebar">
            sidebar 
         </div>
            
        </div>
             
    </div>
    <div id="name" class="break">
        
    </div>


    <div id="footer" class="name">
        footer    
    </div>

</div>
</body>


</html>
